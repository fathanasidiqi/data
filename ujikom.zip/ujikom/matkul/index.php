<?php
include('matkul.php');
$matkul = new matkul();
$data_matkul = $matkul->getAll_matkul();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Mata Kuliah</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 30px;
            max-width: 900px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .add-link {
            text-align: center;
            margin-bottom: 20px;
        }
        .add-link a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            background-color: #e9ecef;
            transition: background-color 0.3s;
        }
        .add-link a:hover {
            background-color: #d6d9dc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .actions a {
            display: inline-block;
            padding: 6px 12px;
            margin-right: 10px;
            border-radius: 4px;
            font-weight: bold;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s, color 0.3s;
        }
        .actions .edit {
            background-color: #28a745;
            color: white;
        }
        .actions .edit:hover {
            background-color: #218838;
        }
        .actions .delete {
            background-color: #dc3545;
            color: white;
        }
        .actions .delete:hover {
            background-color: #c82333;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Daftar Mata Kuliah</h2>
        <div class="add-link">
            <a href="tambah.php">Tambah Mata Kuliah</a>
        </div>
        <table>
            <tr>
                <th>Kode Mata Kuliah</th>
                <th>Nama</th>
                <th>SKS</th>
                <th>Aksi</th>
            </tr>
            <?php while($row = $data_matkul->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['kd_matkul']); ?></td>
                <td><?php echo htmlspecialchars($row['nama']); ?></td>
                <td><?php echo htmlspecialchars($row['sks']); ?></td>
                <td class="actions">
                    <a href="edit.php?id=<?php echo urlencode($row['kd_matkul']); ?>" class="edit">Edit</a>
                    <a href="hapus.php?id=<?php echo urlencode($row['kd_matkul']); ?>" class="delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
    <footer>
        &copy; 2024 Phathan Asidiqi. All rights reserved.
    </footer>
</body>
</html>