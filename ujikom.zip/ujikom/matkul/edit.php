<?php
$kd_matkul = $_GET['id'] ?? '';

if (empty($kd_matkul)) {
    die('Error: ID tidak diberikan.');
}

include('matkul.php');
$matkul = new matkul();
$data_matkul = $matkul->getById($kd_matkul);

if (!$data_matkul) {
    die('Error: Data tidak ditemukan.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $sks = $_POST['sks'];
    $matkul->update_matkul($kd_matkul, $nama, $sks);
    header("Location: index.php?message=Mata kuliah berhasil diperbarui");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mata Kuliah</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 30px;
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }
        input[type="text"] {
            width: calc(100% - 16px);
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 12px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        a {
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
            display: block;
            margin-top: 20px;
            text-align: center;
        }
        a:hover {
            text-decoration: underline;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Edit Mata Kuliah</h2>
        <form method="post">
            <label for="nama">Nama Mata Kuliah:</label>
            <input id="nama" name="nama" type="text" value="<?php echo htmlspecialchars($data_matkul['nama']); ?>" required>
            
            <label for="sks">SKS:</label>
            <input id="sks" name="sks" type="text" value="<?php echo htmlspecialchars($data_matkul['sks']); ?>" required>
            
            <input type="submit" value="Update">
        </form>
        <a href="index.php">Kembali ke Daftar Mata Kuliah</a>
    </div>
    <footer>
        &copy; 2024 app46. All rights reserved.
    </footer>
</body>
</html>