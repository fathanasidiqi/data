<?php
$kd_matkul = $_GET['id'] ?? '';

if (empty($kd_matkul)) {
    die('Error: ID tidak diberikan.');
}

include('matkul.php');
$matkul = new matkul();

try {
    $matkul->hapus_matkul($kd_matkul);
    header("Location: index.php?message=Mata kuliah berhasil dihapus");
    exit();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
