<?php
include('../db.php');

class matkul {
    public $con;

    function __construct() {
        $koneksi = new koneksi();
        $this->con = $koneksi->con;
    }

    function getAll_matkul() {
        $data = $this->con->query("SELECT * FROM tbl_matkul");
        return $data;
    }

    function getById($kd_matkul) {
        $stmt = $this->con->prepare("SELECT * FROM tbl_matkul WHERE kd_matkul = ?");
        $stmt->bind_param("i", $kd_matkul);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    function add_matkul($nama, $sks) {
        $stmt = $this->con->prepare("INSERT INTO tbl_matkul (nama, sks) VALUES (?, ?)");
        $stmt->bind_param("ss", $nama, $sks);
        $stmt->execute();
    }

    function update_matkul($kd_matkul, $nama, $sks) {
        $stmt = $this->con->prepare("UPDATE tbl_matkul SET nama = ?, sks = ? WHERE kd_matkul = ?");
        $stmt->bind_param("ssi", $nama, $sks, $kd_matkul);
        $stmt->execute();
    }

    function hapus_matkul($kd_matkul) {
        $stmt = $this->con->prepare("DELETE FROM tbl_matkul WHERE kd_matkul = ?");
        $stmt->bind_param("i", $kd_matkul);
        $stmt->execute();
    }
}
?>
