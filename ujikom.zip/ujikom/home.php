<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 20px;
            max-width: 900px;
            margin: auto;
        }
        .menu {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 20px;
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            padding: 15px;
            border-radius: 8px;
            flex: 1 1 calc(33% - 15px);
            text-align: center;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
        }
        .menu a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        .logout {
            margin-top: 20px;
            text-align: center;
        }
        .logout a {
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }
        .logout a:hover {
            background-color: #0056b3;
            color: #e9ecef;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
        @media (max-width: 768px) {
            .menu a {
                flex: 1 1 calc(50% - 15px);
            }
        }
        @media (max-width: 480px) {
            .menu a {
                flex: 1 1 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <div class="menu">
            <a href="dosen">Data Dosen</a>
            <a href="matkul">Data Matkul</a>
            <a href="jadwal">Data Jadwal</a>
        </div>
        <div class="logout">
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <footer>
        &copy; 2024 app46. All rights reserved.
    </footer>
</body>
</html>