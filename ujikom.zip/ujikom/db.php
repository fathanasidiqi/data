<?php
class koneksi{
    var $host="localhost";
    var $user="root";
    var $pass="";
    var $db="db_pelatihan46";

    function __construct()
    {
        $this->con=new mysqli($this->host,$this->user,$this->pass,$this->db);
    }

    function get_user($username,$password){
        $data=$this->con->query("SELECT * FROM user WHERE username='$username' and password='$password'");
        return$data;
    }
}
?>