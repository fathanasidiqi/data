<?php
$kd_dosen = $_GET['id'] ?? ''; // Ambil parameter 'id' dari URL

// Periksa apakah 'id' kosong
if (empty($kd_dosen)) {
    die('Error: ID tidak diberikan.');
}

include('dosen.php'); // Sertakan kelas dosen

// Buat instance dari kelas dosen
$dosen = new dosen();

// Ambil data berdasarkan 'id' yang diberikan
$data = $dosen->getBy_dosen($kd_dosen);
$data_edit = $data->fetch_assoc();

// Periksa apakah data ditemukan
if (!$data_edit) {
    die('Error: Data tidak ditemukan.');
}

// Periksa apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data yang dikirimkan dari form
    $nama = $_POST['nama'] ?? '';
    $alamat = $_POST['alamat'] ?? '';

    // Perbarui data di database
    $dosen->update_dosen($kd_dosen, $nama, $alamat);

    // Redirect setelah memperbarui
    header("Location: index.php?message=Data berhasil diperbarui");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dosen</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 30px;
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }
        input[type="text"] {
            width: calc(100% - 16px);
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 12px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Edit Dosen</h2>
        <form method="post">
            <label for="nama">Nama:</label>
            <input id="nama" name="nama" type="text" value="<?php echo htmlspecialchars($data_edit['nama']); ?>" required>
            
            <label for="alamat">Alamat:</label>
            <input id="alamat" name="alamat" type="text" value="<?php echo htmlspecialchars($data_edit['alamat']); ?>" required>
            
            <input type="submit" value="Update">
        </form>
    </div>
    <footer>
        &copy; 2024 app46. All rights reserved.
    </footer>
</body>
</html>