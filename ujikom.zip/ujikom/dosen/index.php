<?php
include('dosen.php'); // Sertakan kelas dosen

// Buat instance dari kelas dosen
$dosen = new dosen();

// Ambil semua data dosen
$data = $dosen->getAll_dosen();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Dosen</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 20px;
            max-width: 1000px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
        }
        .message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }
        .add-link {
            text-align: center;
            margin-bottom: 20px;
        }
        .add-link a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            background-color: #e9ecef;
            transition: background-color 0.3s;
        }
        .add-link a:hover {
            background-color: #d6d9dc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .action-links a {
            display: inline-block;
            padding: 6px 12px;
            margin-right: 10px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            font-size: 14px;
            transition: background-color 0.3s, color 0.3s;
        }
        .action-links .edit {
            background-color: #28a745;
            color: white;
        }
        .action-links .edit:hover {
            background-color: #218838;
        }
        .action-links .delete {
            background-color: #dc3545;
            color: white;
        }
        .action-links .delete:hover {
            background-color: #c82333;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Data Dosen</h2>

        <!-- Tampilkan pesan jika ada -->
        <?php if (isset($_GET['message'])): ?>
            <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
        <?php endif; ?>

        <!-- Tautan untuk menambah data -->
        <p class="add-link"><a href="tambah.php">Tambah Dosen</a></p>

        <!-- Tabel untuk menampilkan data dosen -->
        <table>
            <tr>
                <th>No</th>
                <th>Kode Dosen</th>
                <th>Nama Dosen</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            while ($rec = $data->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($rec['kd_dosen']); ?></td>
                <td><?php echo htmlspecialchars($rec['nama']); ?></td>
                <td><?php echo htmlspecialchars($rec['alamat']); ?></td>
                <td class="action-links">
                    <a href="edit.php?id=<?php echo urlencode($rec['kd_dosen']); ?>" class="edit">Edit</a>
                    <a href="hapus.php?id=<?php echo urlencode($rec['kd_dosen']); ?>" class="delete" onclick="return confirm('Anda yakin ingin menghapus data ini?');">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
    <footer>
        &copy; 2024 Phathan Asidiqi. All rights reserved.
    </footer>
</body>
</html>