<?php
include('../db.php'); // Pastikan jalur ini benar

class dosen {
    private $conn;

    function __construct() {
        $koneksi = new koneksi();
        $this->conn = $koneksi->con;
    }

    function getAll_dosen() {
        $query = "SELECT * FROM tbl_dosen";
        $result = $this->conn->query($query);

        if (!$result) {
            die("Query gagal: " . $this->conn->error);
        }

        return $result;
    }

    function getBy_dosen($kd_dosen) {
        $query = "SELECT * FROM tbl_dosen WHERE kd_dosen = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            die("Prepare gagal: " . $this->conn->error);
        }
        $stmt->bind_param("s", $kd_dosen);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            die("Execute gagal: " . $stmt->error);
        }
        return $result;
    }

    function update_dosen($kd_dosen, $nama, $alamat) {
        $query = "UPDATE tbl_dosen SET nama = ?, alamat = ? WHERE kd_dosen = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            die("Prepare gagal: " . $this->conn->error);
        }
        $stmt->bind_param("sss", $nama, $alamat, $kd_dosen);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    function delete_dosen($kd_dosen) {
        $query = "DELETE FROM tbl_dosen WHERE kd_dosen = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            die("Prepare gagal: " . $this->conn->error);
        }
        $stmt->bind_param("s", $kd_dosen);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

    function add_dosen($kode_dosen, $nama, $alamat) {
        $query = "INSERT INTO tbl_dosen (kd_dosen, nama, alamat) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            die("Prepare gagal: " . $this->conn->error);
        }
        $stmt->bind_param("sss", $kode_dosen, $nama, $alamat);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }
}
?>