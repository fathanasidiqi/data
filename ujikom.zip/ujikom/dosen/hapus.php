<?php
// Ambil ID dosen dari parameter GET
$kd_dosen = $_GET['id'] ?? ''; 

if (empty($kd_dosen)) {
    die('Error: ID tidak diberikan.');
}

include('dosen.php'); // Sertakan kelas dosen

// Buat instance dari kelas dosen
$dosen = new dosen();

// Hapus data berdasarkan ID
$result = $dosen->delete_dosen($kd_dosen);

// Periksa apakah penghapusan berhasil
if ($result) {
    // Redirect ke halaman utama dengan pesan sukses
    header("Location: index.php?message=Data berhasil dihapus");
    exit();
} else {
    // Tampilkan pesan error jika penghapusan gagal
    die('Error: Penghapusan data gagal.');
}
?>
