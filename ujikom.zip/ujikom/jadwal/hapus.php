<?php
$id = $_GET['id'] ?? ''; // Mendapatkan 'id' dari URL

if (empty($id)) {
    die('Error: ID tidak diberikan.');
}

include('jadwal.php'); // Mengimpor kelas jadwal

$jadwal = new jadwal();

try {
    $jadwal->hapus_jadwal($id);
    header("Location: index.php?message=Jadwal berhasil dihapus");
    exit();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
