<?php
include('jadwal.php'); // Menyertakan file jadwal.php

$jadwal = new jadwal(); // Membuat objek jadwal

// Mengambil data jadwal
$data = $jadwal->getAll_jadwal();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Jadwal</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 30px;
            max-width: 1200px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        a {
            display: inline-block;
            padding: 10px 15px;
            margin-bottom: 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        a:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .actions a {
            display: inline-block;
            padding: 6px 12px;
            margin-right: 10px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            font-size: 14px;
            transition: background-color 0.3s, color 0.3s;
        }
        .actions .edit {
            background-color: #28a745;
            color: white;
        }
        .actions .edit:hover {
            background-color: #218838;
        }
        .actions .delete {
            background-color: #dc3545;
            color: white;
        }
        .actions .delete:hover {
            background-color: #c82333;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Daftar Jadwal</h2>
        <a href="tambah.php">Tambah Jadwal</a>
        <table>
            <tr>
                <th>ID</th>
                <th>Kode Mata Kuliah</th>
                <th>Nama Mata Kuliah</th>
                <th>SKS</th>
                <th>Kode Dosen</th>
                <th>Nama Dosen</th>
                <th>Ruang</th>
                <th>Waktu</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['kd_matkul']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_matkul']); ?></td>
                <td><?php echo htmlspecialchars($row['sks']); ?></td>
                <td><?php echo htmlspecialchars($row['kd_dosen']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_dosen']); ?></td>
                <td><?php echo htmlspecialchars($row['ruang']); ?></td>
                <td><?php echo htmlspecialchars($row['waktu']); ?></td>
                <td class="actions">
                    <a href="edit.php?id=<?php echo urlencode($row['id']); ?>" class="edit">Edit</a>
                    <a href="hapus.php?id=<?php echo urlencode($row['id']); ?>" class="delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
    <footer>
        &copy; 2024 Phathan Asidiqi. All rights reserved.
    </footer>
</body>
</html>