<?php
include('../db.php');

class jadwal {
    public $con;

    function __construct() {
        $koneksi = new koneksi();
        $this->con = $koneksi->con;
    }

    function getAll_jadwal() {
        $data = $this->con->query("SELECT j.id, j.kd_matkul, m.nama AS nama_matkul, m.sks, j.kd_dosen, d.nama AS nama_dosen, j.ruang, j.waktu 
                                   FROM tbl_jadwal j 
                                   JOIN tbl_matkul m ON j.kd_matkul = m.kd_matkul 
                                   JOIN tbl_dosen d ON d.kd_dosen = j.kd_dosen;");
        return $data;
    }

    function getById($id) {
        $stmt = $this->con->prepare("SELECT * FROM tbl_jadwal WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    function add_jadwal($kd_dosen, $kd_matkul, $ruang, $waktu) {
        // Check if kd_dosen and kd_matkul exist in their respective tables
        $stmt_dosen = $this->con->prepare("SELECT kd_dosen FROM tbl_dosen WHERE kd_dosen = ?");
        $stmt_dosen->bind_param("i", $kd_dosen);
        $stmt_dosen->execute();
        if ($stmt_dosen->get_result()->num_rows === 0) {
            throw new Exception("kd_dosen tidak valid");
        }

        $stmt_matkul = $this->con->prepare("SELECT kd_matkul FROM tbl_matkul WHERE kd_matkul = ?");
        $stmt_matkul->bind_param("i", $kd_matkul);
        $stmt_matkul->execute();
        if ($stmt_matkul->get_result()->num_rows === 0) {
            throw new Exception("kd_matkul tidak valid");
        }

        // If both exist, proceed to insert the new jadwal
        $stmt = $this->con->prepare("INSERT INTO tbl_jadwal (kd_dosen, kd_matkul, ruang, waktu) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $kd_dosen, $kd_matkul, $ruang, $waktu);
        $stmt->execute();
    }

    function update_jadwal($id, $kd_dosen, $kd_matkul, $ruang, $waktu) {
        $stmt = $this->con->prepare("UPDATE tbl_jadwal SET kd_dosen = ?, kd_matkul = ?, ruang = ?, waktu = ? WHERE id = ?");
        $stmt->bind_param("iissi", $kd_dosen, $kd_matkul, $ruang, $waktu, $id);
        $stmt->execute();
    }

    function hapus_jadwal($id) {
        $stmt = $this->con->prepare("DELETE FROM tbl_jadwal WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}
?>
