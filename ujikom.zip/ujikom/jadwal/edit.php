<?php
include('jadwal.php');

$jadwal = $_GET['id'] ?? '';

if (empty($id)) {
    die('Maaf ID tidak diberikan.');
}

$jadwal = new jadwal();
$data = $jadwal->getById($id);
$data_edit = $data->fetch_assoc();

if (!$data_edit) {
    die('Error: Jadwal tidak ditemukan.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kd_dosen = $_POST['kd_dosen'] ?? '';
    $kd_matkul = $_POST['kd_matkul'] ?? '';
    $ruang = $_POST['ruang'] ?? '';
    $waktu = $_POST['waktu'] ?? '';

    try {
        $jadwal->update_jadwal($id, $kd_dosen, $kd_matkul, $ruang, $waktu);
        header("Location: index.php?message=Jadwal berhasil diupdate");
        exit();
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Jadwal</title>
</head>
<body>
    <h2>Edit Jadwal</h2>
    <form method="post">
        <label for="kd_dosen">Kode Dosen:</label>
        <input id="kd_dosen" name="kd_dosen" type="text" value="<?php echo htmlspecialchars($data_edit['kd_dosen']); ?>" required>
        <br>
        <label for="kd_matkul">Kode Mata Kuliah:</label>
        <input id="kd_matkul" name="kd_matkul" type="text" value="<?php echo htmlspecialchars($data_edit['kd_matkul']); ?>" required>
        <br>
        <label for="ruang">Ruang:</label>
        <input id="ruang" name="ruang" type="text" value="<?php echo htmlspecialchars($data_edit['ruang']); ?>" required>
        <br>
        <label for="waktu">Waktu:</label>
        <input id="waktu" name="waktu" type="text" value="<?php echo htmlspecialchars($data_edit['waktu']); ?>" required>
        <br>
        <input type="submit" value="Update">
    </form>
</body>
</html>
