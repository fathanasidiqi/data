<?php
include('jadwal.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $kd_dosen = $_POST['kd_dosen'] ?? '';
    $kd_matkul = $_POST['kd_matkul'] ?? '';
    $ruang = $_POST['ruang'] ?? '';
    $waktu = $_POST['waktu'] ?? '';

    try {
        // Buat instance class jadwal
        $jadwal = new jadwal();
        
        // Tambahkan jadwal
        $jadwal->add_jadwal($kd_dosen, $kd_matkul, $ruang, $waktu);

        // Redirect setelah berhasil
        header("Location: index.php?message=Jadwal berhasil ditambahkan");
        exit();
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Jadwal</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #007BFF;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            flex: 1;
            padding: 30px;
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        footer {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Selamat datang di app46</h1>
    </header>
    <div class="container">
        <h2>Tambah Jadwal</h2>
        <form method="post">
            <label for="kd_dosen">Kode Dosen:</label>
            <input id="kd_dosen" name="kd_dosen" type="text" required>
            <label for="kd_matkul">Kode Mata Kuliah:</label>
            <input id="kd_matkul" name="kd_matkul" type="text" required>
            <label for="ruang">Ruang:</label>
            <input id="ruang" name="ruang" type="text" required>
            <label for="waktu">Waktu:</label>
            <input id="waktu" name="waktu" type="text" required>
            <input type="submit" value="Tambah">
        </form>
    </div>
    <footer>
        &copy; 2024 app46. All rights reserved.
    </footer>
</body>
</html>