<?php

//fungsi menampilkan
function select($query)
{
  global $db;

  $result = mysqli_query($db, $query);
  $rows =[];

  while ($row = mysqli_fetch_assoc($result)){
    $rows[] = $row;
  }

  return $rows;
}

// fungsi untuk menambahkan data barang
function create_barang($POST)
{
  global $db;

  $nama   = $POST['nama'];
  $jumlah = $POST['jumlah'];
  $harga  = $POST['harga'];

  //query tambah data
  $query = "INSERT INTO barang VALUES(null, '$nama', '$jumlah', '$harga', CURRENT_TIMESTAMP())";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}

//fungsi mengubah data barang 
function update_barang($POST)
{
  global $db;

  $id_barang  = $POST['id_barang'];
  $nama       = $POST['nama'];
  $jumlah     = $POST['jumlah'];
  $harga      = $POST['harga'];

  //query ubah data
  $query = "UPDATE barang SET nama= '$nama', jumlah= '$jumlah', harga=  '$harga' WHERE id_barang = $id_barang";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}

// fungsi menghapus data barang
function delete_barang($id_barang)
{
  global $db;

//query hapus data barang
  $query = "DELETE FROM barang WHERE id_barang = $id_barang";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}


//fungsi untuk menambahkan data mahasiswa
function create_mahasiswa($POST)
{
  global $db;

  $nama     = $POST['nama'];
  $prodi    = $POST['prodi'];
  $jk       = $POST['jk'];
  $telepon  = $POST['telepon'];
  $email    = $POST['email'];

  //query tambah data
  $query = "INSERT INTO mahasiswa VALUES(null, '$nama', '$prodi', '$jk', '$telepon', '$email' )";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}

//fungsi mengubah data Mahasiswa 
function update_mahasiswa($POST)
{
  global $db;
  $id_mahasiswa  = $POST['id_mahasiswa'];
  $nama          = $POST['nama'];
  $prodi         = $POST['prodi'];
  $jk            = $POST['jk'];
  $telepon       = $POST['telepon'];
  $email         = $POST['email'];

  //query update data
  $query = "UPDATE mahasiswa SET nama= '$nama', prodi= '$prodi', jk=  '$jk', 
  telepon= '$telepon', email= '$email' WHERE id_mahasiswa = $id_mahasiswa";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}

// fungsi menghapus data mahasiswa
function delete_mahasiswa($id_mahasiswa)
{
  global $db;

  //query hapus data mahasiswa
  $query = "DELETE FROM mahasiswa WHERE id_mahasiswa = $id_mahasiswa";

  mysqli_query($db, $query);

  return mysqli_affected_rows($db);
}

