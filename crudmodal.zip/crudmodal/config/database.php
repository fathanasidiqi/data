<?php

$db = mysqli_connect('localhost','root', '','crudmodal');

//fungsi login
class koneksi{
    var $host="localhost";
    var $user="root";
    var $pass="";
    var $db="crudmodal";
  
    function __construct()
    {
        $this->con=new mysqli($this->host,$this->user,$this->pass,$this->db);
    }
  
    function get_user($username,$password){
        $data=$this->con->query("SELECT * FROM users WHERE username='$username' and password='$password'");
        return$data;
    }
  }